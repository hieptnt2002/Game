package com.packtpub.libgdx.util;

public class Constants {
	  
	public static final float VIEWPORT_WIDTH = 5.0f; 
	
	public static final float VIEWPORT_HEIGHT = 5.0f;
}
