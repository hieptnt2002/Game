package com.packtpub.libgdx.canyonbunny;

import javax.swing.SpringLayout.Constraints;

import com.badlogic.gdx.Application;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.Disposable;
import com.packtpub.libgdx.util.Constants;

public class WorldRenderer implements Disposable{
	
	private OrthographicCamera camera;
	WorldRenderer worldRenderer;
	private SpriteBatch batch;
	private boolean paused;
	private WorldController worldController;
	
	
	
	public WorldRenderer(WorldController worldController) {
		this.worldController = worldController;
		init();
	}
	private void init() {
		batch=new SpriteBatch();
		camera=new OrthographicCamera(Constants.VIEWPORT_WIDTH,Constants.VIEWPORT_HEIGHT);
		camera.position.set(0,0,0);
		camera.update();
	};


	
	public void render() {
		// TODO Auto-generated method stub
		renderTestOjects();
		
	}
	public void renderTestOjects() {
		batch.setProjectionMatrix(camera.combined);
		batch.begin();
		
			worldController.pikachu.draw(batch);
			worldController.cloud.draw(batch);
			worldController.pikachu2.draw(batch);
	
		batch.end();
	}
	 public void resize (int width, int height) {    
		 camera.viewportWidth = (Constants.VIEWPORT_HEIGHT / height) * width;  
		 camera.update();
	}
 @Override  
 	public void dispose () {  
	 batch.dispose();
	 }

}