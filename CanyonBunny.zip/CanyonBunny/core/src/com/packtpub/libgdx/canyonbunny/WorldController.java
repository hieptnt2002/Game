package com.packtpub.libgdx.canyonbunny;


import com.badlogic.gdx.Application.ApplicationType;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Pixmap.Format;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.math.MathUtils;

public class WorldController {
//	public Sprite[] testSprites;
	public Sprite cloud,pikachu,tam,pikachu2;
	public int selectedSprite;
	private static final String TAG = WorldController.class.getName();
	public WorldController() {
		init();
	};
	private void init() {
		initTestOjects();
	};
	
	private void initTestOjects() {
//		testSprites=new Sprite[5];
		int width=32;
		int height=32;
//		Pixmap pixmap=createProceduralPixmap(width,height);
//		Texture texture=new Texture(pixmap);
		
		Texture texturePi=new Texture("pikachu.jpg");
		Texture texturePi2=new Texture("pdrAYA.jpg");
		Texture textureCl=new Texture("cloud.png");
//		for(int i = 0;i<testSprites.length;i++) {
			Sprite sprPi=new Sprite(texturePi);
			Sprite sprPi2=new Sprite(texturePi2);
			Sprite sprCl=new Sprite(textureCl);
			sprPi.setSize(1, 1);
			sprCl.setSize(1, 1);
			sprPi2.setSize(1, 1);
			sprPi.setOrigin(sprPi.getWidth()/2.0f, sprPi.getHeight()/2.0f);
			sprPi2.setOrigin(sprPi2.getWidth()/2.0f, sprPi2.getHeight()/2.0f);

			sprCl.setOrigin(sprCl.getWidth()/2.0f, sprCl.getHeight()/2.0f);
//			float randomX=MathUtils.random(-2.0f,2.0f);
//			float rabdomY=MathUtils.random(-2.0f,2.0f);
			sprPi.setPosition(1f,0.9f);
			sprPi2.setPosition(0.2f,0.9f);

			sprCl.setPosition(0f,0.2f);
//			testSprites[i]=spr;	
			pikachu=sprPi;
			pikachu2=sprPi2;
			cloud=sprCl;
			tam=pikachu;
//		}
		
//		selectedSprite=0;
	}
//	private Pixmap createProceduralPixmap(int width,int height) {
//		Pixmap pixmap=new Pixmap(width,height,Format.RGBA8888);
//		pixmap.setColor(1,0,0,0.5f);
//		pixmap.fill();
//		pixmap.setColor(1,1,0,1);
//		pixmap.drawLine( 0, 0,width,height);
//		pixmap.drawLine(width, 0, 0, height);
//		pixmap.setColor(0,1,1,1);
//		pixmap.drawRectangle(0, 0, width, height);
//		return pixmap;
//	}
	public void update(float deltaTime) {
		handleDebugInput(deltaTime);
		updateTestOjects(deltaTime);
	};
	private void updateTestOjects(float deltaTine) {
//		float rotation=testSprites[selectedSprite].getRotation();
//		rotation+=90*deltaTine;
//		rotation%=360;
//		testSprites[selectedSprite].setRotation(rotation);
		float rotation=tam.getRotation();
		rotation+=90*deltaTine;
		rotation%=360;
		tam.setRotation(rotation);
		
	}
	
	 private void handleDebugInput (float deltaTime) {
		 
		 if (Gdx.app.getType() != ApplicationType.Desktop) return;
		 // Selected Sprite Controls
		 float sprMoveSpeed = 1 * deltaTime;
		 if (Gdx.input.isKeyPressed(Keys.A)) moveSelectedSprite(
		 -sprMoveSpeed, 0);
		 if (Gdx.input.isKeyPressed(Keys.D))
		 moveSelectedSprite(sprMoveSpeed, 0);
		 if (Gdx.input.isKeyPressed(Keys.W)) moveSelectedSprite(0,
		 sprMoveSpeed);
		 if (Gdx.input.isKeyPressed(Keys.S)) moveSelectedSprite(0,
		 -sprMoveSpeed);
		 if(Gdx.input.isKeyJustPressed(Keys.NUM_1)) {
			
			tam=cloud;
		 }
		 if(Gdx.input.isKeyJustPressed(Keys.NUM_2)) {
				
				tam=pikachu;
			 }
		 if(Gdx.input.isKeyJustPressed(Keys.NUM_3)) {
				
				tam=pikachu2;
			 }
		 
		 
		 }
		 private void moveSelectedSprite (float x, float y) {
		 tam.translate(x, y);
		 }
}
